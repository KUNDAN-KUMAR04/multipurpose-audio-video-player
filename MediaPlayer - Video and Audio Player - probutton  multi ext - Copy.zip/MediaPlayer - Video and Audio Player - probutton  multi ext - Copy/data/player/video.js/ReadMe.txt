https://cdn.jsdelivr.net/npm/video.js@8.23.3/dist/video-js.css
https://cdn.jsdelivr.net/npm/video.js@8.23.3/dist/video.js
  -> removing "https://vjs.zencdn.net/vttjs/0.14.1/vtt.min.js" per Chrome review
