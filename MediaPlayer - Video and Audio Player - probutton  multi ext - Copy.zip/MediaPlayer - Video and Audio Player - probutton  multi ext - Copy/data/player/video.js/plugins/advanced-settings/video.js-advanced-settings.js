/* globals videojs */
'use strict';

{
  const Plugin = videojs.getPlugin('plugin');
  const Button = videojs.getComponent('Button');

  // Settings Button Component
  class AdvancedSettingsButton extends Button {
    constructor(player, options) {
      super(player, options);
      this.controlText('Advanced Settings');
    }

    buildCSSClass() {
      return `vjs-advanced-settings-button ${super.buildCSSClass()}`;
    }

    handleClick() {
      this.player().trigger('openAdvancedSettings');
    }
  }

  videojs.registerComponent('AdvancedSettingsButton', AdvancedSettingsButton);

  // Main Plugin
  class AdvancedSettingsPlugin extends Plugin {
    #overlay = null;
    #popup = null;
    #currentTab = 'video';
    #audioContext = null;
    #mediaElements = new Map();
    
    // Settings state
    #settings = {
      video: {
        brightness: 100,
        contrast: 100,
        saturation: 100,
        opacity: 100,
        blur: 0,
        grayscale: 0,
        sepia: 0,
        hueRotate: 0,
        invert: 0,
        rotateZ: 0,
        rotateX: 0,
        rotateY: 0,
        scaleX: 1,
        scaleY: 1,
        translateX: 0,
        translateY: 0
      },
      audio: {
        volume: 100,
        qualityMode: 'balanced'
      },
      player: {
        autoHideControls: true,
        captionsEnabled: false
      }
    };

    constructor(player, options) {
      super(player, options);

      // Load saved settings
      this.loadSettings();

      // Create UI
      player.on('ready', () => {
        this.createPopupUI();
        this.addSettingsButton();
        this.applySettings();
      });

      // Listen for open event
      player.on('openAdvancedSettings', () => {
        this.openPopup();
      });
    }

    addSettingsButton() {
      const player = this.player;
      const controlBar = player.controlBar;
      
      // Add settings button to control bar
      const settingsButton = controlBar.addChild('AdvancedSettingsButton', {}, 
        controlBar.children().indexOf(controlBar.fullscreenToggle)
      );
    }

    createPopupUI() {
      const player = this.player;
      const playerEl = player.el();

      // Create overlay
      this.#overlay = document.createElement('div');
      this.#overlay.className = 'vjs-advanced-settings-overlay';
      this.#overlay.addEventListener('click', (e) => {
        if (e.target === this.#overlay) {
          this.closePopup();
        }
      });

      // Create popup container
      this.#popup = document.createElement('div');
      this.#popup.className = 'vjs-advanced-settings-popup';

      // Build popup HTML
      this.#popup.innerHTML = `
        <div class="vjs-advanced-settings-header">
          <div class="vjs-advanced-settings-title">
            <span>⚙️</span>
            <span>Advanced Settings</span>
          </div>
          <button class="vjs-advanced-settings-close" id="vjs-settings-close">×</button>
        </div>

        <div class="vjs-settings-tabs">
          <button class="vjs-settings-tab active" data-tab="video">🎬 Video</button>
          <button class="vjs-settings-tab" data-tab="audio">🔊 Audio</button>
          <button class="vjs-settings-tab" data-tab="player">⚡ Player</button>
        </div>

        <div class="vjs-settings-content">
          <!-- Video Enhancement Tab -->
          <div class="vjs-settings-tab-panel active" data-panel="video">
            <div class="vjs-settings-section-title">Color & Brightness</div>
            
            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Brightness</span>
                <span class="vjs-settings-control-value" id="brightness-val">100%</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="brightness" min="0" max="200" value="100">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Contrast</span>
                <span class="vjs-settings-control-value" id="contrast-val">100%</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="contrast" min="0" max="200" value="100">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Saturation</span>
                <span class="vjs-settings-control-value" id="saturation-val">100%</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="saturation" min="0" max="200" value="100">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Opacity</span>
                <span class="vjs-settings-control-value" id="opacity-val">100%</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="opacity" min="0" max="100" value="100">
            </div>

            <div class="vjs-settings-section-title">Effects</div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Blur</span>
                <span class="vjs-settings-control-value" id="blur-val">0px</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="blur" min="0" max="10" value="0" step="0.5">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Grayscale</span>
                <span class="vjs-settings-control-value" id="grayscale-val">0%</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="grayscale" min="0" max="100" value="0">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Sepia</span>
                <span class="vjs-settings-control-value" id="sepia-val">0%</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="sepia" min="0" max="100" value="0">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Hue Rotate</span>
                <span class="vjs-settings-control-value" id="hueRotate-val">0°</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="hueRotate" min="0" max="360" value="0">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Invert</span>
                <span class="vjs-settings-control-value" id="invert-val">0%</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="invert" min="0" max="100" value="0">
            </div>

            <div class="vjs-settings-section-title">Transform & Rotation</div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Rotate</span>
                <span class="vjs-settings-control-value" id="rotateZ-val">0°</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="rotateZ" min="-180" max="180" value="0">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Flip Horizontal</span>
                <span class="vjs-settings-control-value" id="rotateY-val">Normal</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="rotateY" min="0" max="180" value="0" step="180">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Flip Vertical</span>
                <span class="vjs-settings-control-value" id="rotateX-val">Normal</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="rotateX" min="0" max="180" value="0" step="180">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Scale Horizontal</span>
                <span class="vjs-settings-control-value" id="scaleX-val">1.0x</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="scaleX" min="0.5" max="2" value="1" step="0.1">
            </div>

            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Scale Vertical</span>
                <span class="vjs-settings-control-value" id="scaleY-val">1.0x</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="scaleY" min="0.5" max="2" value="1" step="0.1">
            </div>

            <div class="vjs-settings-actions">
              <button class="vjs-settings-btn vjs-settings-btn-reset" id="reset-video">Reset Video</button>
              <button class="vjs-settings-btn vjs-settings-btn-save" id="save-video">Save Settings</button>
            </div>
          </div>

          <!-- Audio Boost Tab -->
          <div class="vjs-settings-tab-panel" data-panel="audio">
            <div class="vjs-settings-section-title">Volume Boost</div>
            
            <div class="vjs-settings-control-group">
              <div class="vjs-settings-control-label">
                <span>Volume</span>
                <span class="vjs-settings-control-value" id="volume-val">100%</span>
              </div>
              <input type="range" class="vjs-settings-slider" id="volume" min="0" max="1000" value="100" step="10">
            </div>

            <div class="vjs-settings-preset-grid">
              <button class="vjs-settings-preset-btn" data-volume="50">50%</button>
              <button class="vjs-settings-preset-btn" data-volume="100">100%</button>
              <button class="vjs-settings-preset-btn" data-volume="200">200%</button>
              <button class="vjs-settings-preset-btn" data-volume="300">300%</button>
              <button class="vjs-settings-preset-btn" data-volume="500">500%</button>
              <button class="vjs-settings-preset-btn" data-volume="800">800%</button>
            </div>

            <div class="vjs-settings-section-title">Audio Quality Mode</div>
            
            <div class="vjs-settings-quality-modes">
              <button class="vjs-settings-quality-btn" data-quality="maximum_quality">
                <div class="vjs-settings-quality-title">🎵 Maximum Quality</div>
                <div class="vjs-settings-quality-desc">Best sound, gentle boost - preserves dynamics</div>
              </button>
              <button class="vjs-settings-quality-btn active" data-quality="balanced">
                <div class="vjs-settings-quality-title">⚖️ Balanced</div>
                <div class="vjs-settings-quality-desc">Great quality + volume - recommended</div>
              </button>
              <button class="vjs-settings-quality-btn" data-quality="maximum_loudness">
                <div class="vjs-settings-quality-title">🔥 Maximum Loudness</div>
                <div class="vjs-settings-quality-desc">Loudest possible - aggressive compression</div>
              </button>
            </div>

            <div class="vjs-settings-actions">
              <button class="vjs-settings-btn vjs-settings-btn-reset" id="reset-audio">Reset Audio</button>
              <button class="vjs-settings-btn vjs-settings-btn-save" id="save-audio">Save Settings</button>
            </div>
          </div>

          <!-- Player Settings Tab -->
          <div class="vjs-settings-tab-panel" data-panel="player">
            <div class="vjs-settings-section-title">Player Options</div>
            
            <div class="vjs-settings-toggle-group">
              <div class="vjs-settings-toggle-label">Auto-hide Controls</div>
              <div class="vjs-settings-toggle active" id="toggle-auto-hide">
                <div class="vjs-settings-toggle-handle"></div>
              </div>
            </div>

            <div class="vjs-settings-toggle-group">
              <div class="vjs-settings-toggle-label">Enable Captions by Default</div>
              <div class="vjs-settings-toggle" id="toggle-captions">
                <div class="vjs-settings-toggle-handle"></div>
              </div>
            </div>

            <div class="vjs-settings-section-title">Keyboard Shortcuts</div>
            <div style="font-size: 13px; color: #ccc; line-height: 1.8;">
              <div>⬆️ <strong>Alt + V</strong> - Toggle Advanced Settings</div>
              <div>🔄 <strong>Alt + R</strong> - Reset All Settings</div>
              <div>⏯️ <strong>Space</strong> - Play/Pause</div>
              <div>⏩ <strong>→</strong> - Seek Forward</div>
              <div>⏪ <strong>←</strong> - Seek Backward</div>
              <div>🔊 <strong>↑</strong> - Volume Up</div>
              <div>🔉 <strong>↓</strong> - Volume Down</div>
              <div>🖥️ <strong>F</strong> - Fullscreen</div>
            </div>

            <div class="vjs-settings-actions">
              <button class="vjs-settings-btn vjs-settings-btn-reset" id="reset-all">Reset All Settings</button>
            </div>
          </div>
        </div>
      `;

      this.#overlay.appendChild(this.#popup);
      playerEl.appendChild(this.#overlay);

      this.attachEventListeners();
      this.updateUI();
    }

    attachEventListeners() {
      const popup = this.#popup;

      // Close button
      popup.querySelector('#vjs-settings-close').addEventListener('click', () => {
        this.closePopup();
      });

      // Tab switching
      popup.querySelectorAll('.vjs-settings-tab').forEach(tab => {
        tab.addEventListener('click', (e) => {
          const tabName = e.target.dataset.tab;
          this.switchTab(tabName);
        });
      });

      // Video enhancement sliders
      const videoControls = ['brightness', 'contrast', 'saturation', 'opacity', 'blur', 
        'grayscale', 'sepia', 'hueRotate', 'invert', 'rotateZ', 'rotateX', 'rotateY', 
        'scaleX', 'scaleY'];
      
      videoControls.forEach(key => {
        const slider = popup.querySelector(`#${key}`);
        if (slider) {
          slider.addEventListener('input', (e) => {
            const value = parseFloat(e.target.value);
            this.#settings.video[key] = value;
            this.updateVideoDisplay(key, value);
            this.applyVideoFilters();
          });
        }
      });

      // Volume slider
      const volumeSlider = popup.querySelector('#volume');
      volumeSlider.addEventListener('input', (e) => {
        const value = parseInt(e.target.value);
        this.#settings.audio.volume = value;
        this.updateAudioDisplay(value);
        this.applyAudioBoost(value);
      });

      // Volume presets
      popup.querySelectorAll('[data-volume]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const volume = parseInt(e.target.dataset.volume);
          volumeSlider.value = volume;
          this.#settings.audio.volume = volume;
          this.updateAudioDisplay(volume);
          this.applyAudioBoost(volume);
        });
      });

      // Quality mode buttons
      popup.querySelectorAll('[data-quality]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          popup.querySelectorAll('[data-quality]').forEach(b => b.classList.remove('active'));
          e.currentTarget.classList.add('active');
          const mode = e.currentTarget.dataset.quality;
          this.#settings.audio.qualityMode = mode;
          this.updateAudioQuality(mode);
        });
      });

      // Toggle switches
      popup.querySelector('#toggle-auto-hide').addEventListener('click', (e) => {
        e.currentTarget.classList.toggle('active');
        this.#settings.player.autoHideControls = e.currentTarget.classList.contains('active');
      });

      popup.querySelector('#toggle-captions').addEventListener('click', (e) => {
        e.currentTarget.classList.toggle('active');
        this.#settings.player.captionsEnabled = e.currentTarget.classList.contains('active');
      });

      // Reset buttons
      popup.querySelector('#reset-video').addEventListener('click', () => this.resetVideoSettings());
      popup.querySelector('#reset-audio').addEventListener('click', () => this.resetAudioSettings());
      popup.querySelector('#reset-all').addEventListener('click', () => this.resetAllSettings());

      // Save buttons
      popup.querySelector('#save-video').addEventListener('click', () => this.saveSettings('video'));
      popup.querySelector('#save-audio').addEventListener('click', () => this.saveSettings('audio'));

      // Keyboard shortcuts
      document.addEventListener('keydown', (e) => {
        if (e.altKey && e.key === 'v') {
          e.preventDefault();
          this.togglePopup();
        }
        if (e.altKey && e.key === 'r') {
          e.preventDefault();
          this.resetAllSettings();
        }
      });

      // Escape to close
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && this.#overlay.classList.contains('active')) {
          this.closePopup();
        }
      });
    }

    switchTab(tabName) {
      this.#currentTab = tabName;
      
      // Update tab buttons
      this.#popup.querySelectorAll('.vjs-settings-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.tab === tabName);
      });

      // Update panels
      this.#popup.querySelectorAll('.vjs-settings-tab-panel').forEach(panel => {
        panel.classList.toggle('active', panel.dataset.panel === tabName);
      });
    }

    updateVideoDisplay(key, value) {
      const displayEl = this.#popup.querySelector(`#${key}-val`);
      if (!displayEl) return;

      let displayValue;
      switch(key) {
        case 'blur':
          displayValue = `${value}px`;
          break;
        case 'rotateZ':
        case 'hueRotate':
          displayValue = `${value}°`;
          break;
        case 'rotateX':
        case 'rotateY':
          displayValue = value === 0 ? 'Normal' : 'Flipped';
          break;
        case 'scaleX':
        case 'scaleY':
          displayValue = `${value}x`;
          break;
        default:
          displayValue = `${value}%`;
      }
      
      displayEl.textContent = displayValue;
    }

    updateAudioDisplay(volume) {
      const displayEl = this.#popup.querySelector('#volume-val');
      displayEl.textContent = `${volume}%`;
    }

    applyVideoFilters() {
      const player = this.player;
      const videoEl = player.el().querySelector('video');
      if (!videoEl) return;

      const s = this.#settings.video;
      
      const filterString = `
        brightness(${s.brightness}%)
        contrast(${s.contrast}%)
        saturate(${s.saturation}%)
        blur(${s.blur}px)
        grayscale(${s.grayscale}%)
        sepia(${s.sepia}%)
        hue-rotate(${s.hueRotate}deg)
        invert(${s.invert}%)
      `.trim();

      const transformString = `
        rotateZ(${s.rotateZ}deg)
        rotateX(${s.rotateX}deg)
        rotateY(${s.rotateY}deg)
        scaleX(${s.scaleX})
        scaleY(${s.scaleY})
      `.trim();

      videoEl.style.filter = filterString;
      videoEl.style.transform = transformString;
      videoEl.style.opacity = s.opacity / 100;
    }

    applyAudioBoost(volume) {
      const player = this.player;
      const videoEl = player.el().querySelector('video');
      if (!videoEl) return;

      const volumeMultiplier = volume / 100;

      // For volume <= 100%, use native volume
      if (volumeMultiplier <= 1.0) {
        videoEl.volume = Math.min(1.0, volumeMultiplier);
        
        // Disconnect Web Audio if connected
        if (this.#mediaElements.has(videoEl)) {
          const data = this.#mediaElements.get(videoEl);
          if (data.source) {
            try {
              data.source.disconnect();
              data.gainNode.disconnect();
            } catch (e) {}
          }
          this.#mediaElements.delete(videoEl);
        }
        return;
      }

      // For volume > 100%, use Web Audio API
      if (!this.#audioContext) {
        this.#audioContext = new (window.AudioContext || window.webkitAudioContext)();
      }

      try {
        let data = this.#mediaElements.get(videoEl);
        
        if (!data) {
          const source = this.#audioContext.createMediaElementSource(videoEl);
          const gainNode = this.#audioContext.createGain();
          
          source.connect(gainNode);
          gainNode.connect(this.#audioContext.destination);
          
          data = { source, gainNode };
          this.#mediaElements.set(videoEl, data);
        }

        videoEl.volume = 1.0;
        data.gainNode.gain.setValueAtTime(volumeMultiplier, this.#audioContext.currentTime);

      } catch (e) {
        console.warn('Could not boost audio:', e);
        videoEl.volume = 1.0;
      }
    }

    updateAudioQuality(mode) {
      // Audio quality settings would be applied here
      // For now, just store the preference
      console.log('Audio quality mode:', mode);
    }

    resetVideoSettings() {
      this.#settings.video = {
        brightness: 100,
        contrast: 100,
        saturation: 100,
        opacity: 100,
        blur: 0,
        grayscale: 0,
        sepia: 0,
        hueRotate: 0,
        invert: 0,
        rotateZ: 0,
        rotateX: 0,
        rotateY: 0,
        scaleX: 1,
        scaleY: 1,
        translateX: 0,
        translateY: 0
      };
      this.updateUI();
      this.applySettings();
    }

    resetAudioSettings() {
      this.#settings.audio = {
        volume: 100,
        qualityMode: 'balanced'
      };
      this.updateUI();
      this.applySettings();
    }

    resetAllSettings() {
      this.resetVideoSettings();
      this.resetAudioSettings();
      this.#settings.player = {
        autoHideControls: true,
        captionsEnabled: false
      };
      this.updateUI();
      this.applySettings();
      this.saveSettings('all');
    }

    updateUI() {
      if (!this.#popup) return;

      // Update video controls
      Object.keys(this.#settings.video).forEach(key => {
        const slider = this.#popup.querySelector(`#${key}`);
        if (slider) {
          slider.value = this.#settings.video[key];
          this.updateVideoDisplay(key, this.#settings.video[key]);
        }
      });

      // Update audio controls
      const volumeSlider = this.#popup.querySelector('#volume');
      if (volumeSlider) {
        volumeSlider.value = this.#settings.audio.volume;
        this.updateAudioDisplay(this.#settings.audio.volume);
      }

      // Update quality mode
      this.#popup.querySelectorAll('[data-quality]').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.quality === this.#settings.audio.qualityMode);
      });

      // Update toggles
      const autoHideToggle = this.#popup.querySelector('#toggle-auto-hide');
      if (autoHideToggle) {
        autoHideToggle.classList.toggle('active', this.#settings.player.autoHideControls);
      }

      const captionsToggle = this.#popup.querySelector('#toggle-captions');
      if (captionsToggle) {
        captionsToggle.classList.toggle('active', this.#settings.player.captionsEnabled);
      }
    }

    applySettings() {
      this.applyVideoFilters();
      this.applyAudioBoost(this.#settings.audio.volume);
      this.updateAudioQuality(this.#settings.audio.qualityMode);
    }

    saveSettings(type = 'all') {
      chrome.storage.local.set({ 
        advancedSettings: this.#settings 
      }, () => {
        this.showNotification(`${type === 'all' ? 'All' : type.charAt(0).toUpperCase() + type.slice(1)} settings saved!`);
      });
    }

    loadSettings() {
      chrome.storage.local.get(['advancedSettings'], (result) => {
        if (result.advancedSettings) {
          this.#settings = { ...this.#settings, ...result.advancedSettings };
        }
      });
    }

    showNotification(message) {
      const notification = document.createElement('div');
      notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        padding: 16px 24px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        z-index: 10001;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        animation: slideIn 0.3s ease-out;
      `;
      notification.textContent = message;
      document.body.appendChild(notification);

      setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(400px)';
        notification.style.transition = 'all 0.3s';
        setTimeout(() => notification.remove(), 300);
      }, 2000);
    }

    togglePopup() {
      if (this.#overlay.classList.contains('active')) {
        this.closePopup();
      } else {
        this.openPopup();
      }
    }

    openPopup() {
      this.#overlay.classList.add('active');
      this.updateUI();
    }

    closePopup() {
      this.#overlay.classList.remove('active');
    }
  }

  videojs.registerPlugin('advancedSettingsPlugin', AdvancedSettingsPlugin);
}
