/* globals videojs */
'use strict';

{
  const Plugin = videojs.getPlugin('plugin');

  class PlayBackRatePlugin extends Plugin {
    #rate;
    #popup = null;
    #overlay = null;
    #indicator = null;

    constructor(player, options) {
      super(player, options);

      this.#rate = player.playbackRate();

      player.on('ratechange', () => {
        this.#rate = player.playbackRate();
        this.updateUI();
        this.showSpeedIndicator();
      });

      player.on('playlistitem', () => {
        player.playbackRate(this.#rate);
      });

      player.on('ready', () => {
        // Create the popup UI
        this.createPopupUI();
        
        // Create speed indicator overlay
        this.createSpeedIndicator();

        // Override the default click handler on the playback rate button
        const rateButton = player.controlBar.playbackRateMenuButton;
        if (rateButton) {
          rateButton.el().addEventListener('click', e => {
            e.preventDefault();
            e.stopPropagation();
            this.togglePopup();
          }, true);

          // Hide the default menu
          rateButton.hideMenu();
        }
      });
    }

    createSpeedIndicator() {
      const player = this.player;
      const playerEl = player.el();
      
      this.#indicator = document.createElement('div');
      this.#indicator.className = 'vjs-speed-indicator';
      playerEl.appendChild(this.#indicator);
    }

    showSpeedIndicator() {
      if (!this.#indicator) return;
      
      this.#indicator.textContent = this.#rate + 'x';
      this.#indicator.classList.add('show');
      
      setTimeout(() => {
        this.#indicator.classList.remove('show');
      }, 1500);
    }

    createPopupUI() {
      const player = this.player;
      const playerEl = player.el();

      // Create overlay
      this.#overlay = document.createElement('div');
      this.#overlay.className = 'vjs-speed-popup-overlay';
      this.#overlay.addEventListener('click', (e) => {
        if (e.target === this.#overlay) {
          this.closePopup();
        }
      });

      // Create popup container
      this.#popup = document.createElement('div');
      this.#popup.className = 'vjs-speed-popup';

      // Build popup HTML
      this.#popup.innerHTML = `
        <div class="header">
          <span class="header-title">Speed</span>
          <span class="speed-badge" id="currentSpeed">${this.#rate.toFixed(1)}</span>
        </div>

        <!-- Max Speed Section -->
        <div class="max-speed-section">
          <div class="max-speed-row">
            <input type="number" class="max-speed-input" id="maxSpeedInput" 
                   step="0.1" min="0.1" max="100" placeholder="Any speed" value="16">
            <button class="max-speed-btn" id="maxSpeedBtn">▶▶ MAX</button>
          </div>
        </div>

        <!-- Preset Buttons -->
        <div class="preset-grid">
          <button class="preset-btn" data-speed="1.0">1x</button>
          <button class="preset-btn" data-speed="1.5">1.5x</button>
          <button class="preset-btn" data-speed="2.0">2x</button>
          <button class="preset-btn" data-speed="2.5">2.5x</button>
          <button class="preset-btn" data-speed="3.0">3x</button>
          <button class="preset-btn" data-speed="3.5">3.5x</button>
          <button class="preset-btn" data-speed="4.0">4x</button>
          <button class="preset-btn" data-speed="4.5">4.5x</button>
          <button class="preset-btn" data-speed="5.0">5x</button>
        </div>

        <!-- Custom Input Section -->
        <div class="input-group">
          <div class="custom-row">
            <label class="custom-label">Custom Input</label>
            <input type="number" class="custom-number-input" id="customNumberInput" 
                   step="0.1" min="0.1" max="16">
          </div>
          <input type="range" class="custom-slider" id="customSlider" 
                 step="0.1" min="0.1" max="10" value="1.0">
        </div>
      `;

      this.#overlay.appendChild(this.#popup);
      playerEl.appendChild(this.#overlay);

      // Attach event listeners
      this.attachPopupListeners();
      this.updateUI();
    }

    attachPopupListeners() {
      const popup = this.#popup;

      // Preset buttons
      popup.querySelectorAll('.preset-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const speed = parseFloat(btn.dataset.speed);
          this.setSpeed(speed);
        });
      });

      // Max speed button
      const maxSpeedBtn = popup.querySelector('#maxSpeedBtn');
      const maxSpeedInput = popup.querySelector('#maxSpeedInput');
      
      maxSpeedBtn.addEventListener('click', () => {
        const maxSpeed = parseFloat(maxSpeedInput.value);
        
        if (isNaN(maxSpeed) || maxSpeed < 0.1) {
          alert('Please enter a valid speed (minimum 0.1x)');
          return;
        }
        
        if (maxSpeed > 16) {
          if (!confirm(`You entered ${maxSpeed}x speed. This is higher than the typical maximum of 16x. Continue?`)) {
            return;
          }
        }
        
        this.setSpeed(maxSpeed);
      });

      // Allow Enter key on max speed input
      maxSpeedInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          maxSpeedBtn.click();
        }
      });

      // Custom slider
      const customSlider = popup.querySelector('#customSlider');
      customSlider.addEventListener('input', (e) => {
        this.setSpeed(parseFloat(e.target.value));
      });

      // Custom number input
      const customNumberInput = popup.querySelector('#customNumberInput');
      customNumberInput.addEventListener('change', (e) => {
        this.setSpeed(parseFloat(e.target.value));
      });

      // Keyboard shortcut: Escape to close
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && this.#overlay.classList.contains('active')) {
          this.closePopup();
        }
      });
    }

    updateUI() {
      if (!this.#popup) return;

      const currentSpeed = this.#rate;
      
      // Update speed badge
      this.#popup.querySelector('#currentSpeed').textContent = currentSpeed.toFixed(1);
      
      // Update custom inputs
      this.#popup.querySelector('#customNumberInput').value = currentSpeed;
      this.#popup.querySelector('#customSlider').value = currentSpeed;
      
      // Update active preset button
      this.#popup.querySelectorAll('.preset-btn').forEach(btn => {
        const btnSpeed = parseFloat(btn.dataset.speed);
        if (Math.abs(btnSpeed - currentSpeed) < 0.01) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });
    }

    setSpeed(speed) {
      this.#rate = speed;
      this.player.playbackRate(speed);
      this.updateUI();
      
      // Save to localStorage for persistence
      localStorage.setItem('last-playback-rate', speed);
    }

    togglePopup() {
      if (this.#overlay.classList.contains('active')) {
        this.closePopup();
      } else {
        this.openPopup();
      }
    }

    openPopup() {
      this.#overlay.classList.add('active');
      this.updateUI();
      
      // Pause video when opening popup (optional, can be removed)
      // this.player.pause();
    }

    closePopup() {
      this.#overlay.classList.remove('active');
    }

    // Legacy method for compatibility with keyboard shortcuts
    change(direction = 'forward') {
      const {player} = this;
      const rates = player.playbackRates();
      const index = rates.indexOf(this.#rate);

      if (index !== -1) {
        const newIndex = (index + rates.length + (direction === 'forward' ? 1 : -1)) % rates.length;
        this.#rate = rates[newIndex];
        this.setSpeed(this.#rate);
      }
    }
  }

  videojs.registerPlugin('playBackRatePlugin', PlayBackRatePlugin);
}
